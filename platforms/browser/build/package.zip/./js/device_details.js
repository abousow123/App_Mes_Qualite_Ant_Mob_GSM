/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

function getDeviceMarque() {
    return device.manufacturer;
}

function getDeviceModel() {
    return device.model;
}

function getDeviceSerial() {
    return device.serial;
}



